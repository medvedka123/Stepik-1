<img width="528" height="180" alt="image" src="https://github.com/user-attachments/assets/60ae9231-4af4-4478-aec3-19b192e1941a" />
